0 - hate speech
2 - non-hate
