this merges [1] (16k + tweets) with [2] (6900 tweets), by only taking the additional tweets from [2] (ignoring those that overlap with [1], and majority vote where expert has 2 weights and amateur has 1 weight. If tie, trust expert vote.

[1]Waseem, Z. (2016). Are you a racist or am I seeing things? annotator influence on hate speech de- tection on twitter. Proceedings of the 1st Work- shop on Natural Language Processing and Computational Social Science, 138-142. 

[2]Waseem, Z., & Hovy, D. (2016). Hateful symbols or hateful people? predictive features for hate speech detection on twitter. Proceedings of NAACL-HLT, 88-93.


0 - racism; 1 - sexism; 2 - neither; 3 - both
