0 - racism; 1 - sexism; 2 - neither; 3 - both
